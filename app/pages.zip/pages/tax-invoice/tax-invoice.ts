import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the TaxInvoicePage page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  templateUrl: 'build/pages/tax-invoice/tax-invoice.html',
})
export class TaxInvoicePage {

  constructor(private navCtrl: NavController) {
    
  }
  this.http.get('https://pms-service.herokuapp.com/paidVoucher').map(res => { 

      return res.json(); 

    }).subscribe(data => { 

      console.log('Data object in subscribe method:'); 
      console.dir(data); 
      this.items = data; 

    });

}
